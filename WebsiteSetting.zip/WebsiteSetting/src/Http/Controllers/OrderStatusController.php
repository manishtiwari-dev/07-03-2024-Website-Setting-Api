<?php

namespace Modules\WebsiteSetting\Http\Controllers;

use ApiHelper;
use App\Http\Controllers\Controller;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Modules\Ecommerce\Models\OrderStatus;
use Modules\WebsiteSetting\Models\EmailTemplates;
use Modules\WebsiteSetting\Models\SuperEmailTemplates;





class OrderStatusController extends Controller
{
    public $page = 'order_status';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';

    public function index(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageview)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }


        $order_status = OrderStatus::get();
        //  $countrydata = Country::all();

        $template = ApiHelper::getTemplate('website_order_status ');

        $admin_list = EmailTemplates::where('group_id', $template['group_id'])->get();
        $super_list = SuperEmailTemplates::where('group_id', $template['group_id'])->get();

        $merged = $admin_list->merge($super_list);
        $template_list = $merged->all();

        $res = [
            'order_status' => $order_status,
            'template_list' => $template_list
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }


    public function ChangeStatus(Request $request)
    {
        $api_token = $request->api_token;

        if (!empty($request->id)) {

            $OrderStatus = OrderStatus::updateOrCreate(
                ['id'   => $request->id],
                ['status' => $request->status]
            );
        }
        return ApiHelper::JSON_RESPONSE(true, $OrderStatus, 'SUCCESS_STATUS_UPDATE');
    }

    public function shipment_status(Request $request)
    {

        $api_token = $request->api_token;
        if (!empty($request->id)) {

            $OrderStatus = OrderStatus::updateOrCreate(
                ['id'   => $request->id],
                ['shipment' => $request->shipment]
            );
        }

        return ApiHelper::JSON_RESPONSE(true, $OrderStatus, 'SUCCESS_STATUS_UPDATE');
    }


    public function sort_order(Request $request)
    {

        $api_token = $request->api_token;
        if (!empty($request->id)) {

            $OrderStatus = OrderStatus::updateOrCreate(
                ['id'   => $request->id],
                ['sort_order' => $request->sort_order]
            );
        }

        return ApiHelper::JSON_RESPONSE(true, $OrderStatus, 'SUCCESS_SORT_ORDER_UPDATE');
    }

    public function order_template_update(Request $request)
    {
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        $order_status_details = OrderStatus::all();
        $template_order = '';
        foreach ($order_status_details  as $order) {
            $template_id = "template_" . $order->id;
            $template_order =  OrderStatus::updateOrCreate(
                [
                    'id' => $order->id,

                ],
                [
                    'template_id' => $request->formdata[$template_id]

                ]
            );
        }

        if ($template_order) {
            return ApiHelper::JSON_RESPONSE(true, $template_order, 'SUCCESS_ORDER_TEMPLATE_UPDATE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_ORDER_TEMPLATE_UPDATE');
        }
    }
}
