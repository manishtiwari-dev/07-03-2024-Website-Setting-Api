<?php

namespace Modules\WebsiteSetting\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use Modules\WebsiteSetting\Models\PostCategory;
use Modules\WebsiteSetting\Models\PostToCategory;
use Modules\WebsiteSetting\Models\Form;
use Modules\WebsiteSetting\Models\Super\SuperPostCategory;
use Modules\WebsiteSetting\Models\PostCategoryDescription;
use Modules\Ecommerce\Models\SeoMeta;


use Illuminate\Support\Str;

use ApiHelper;


class PostCategoryController extends Controller
{
    public $page = 'blog_setting';
    public $landingpage = 'super_blog_setting';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';


    public function index(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        $page_access = ($userType == 'subscriber' ? $this->page : $this->landingpage);
        if (!ApiHelper::is_page_access($api_token, $page_access, $this->pageview))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');


        $current_page = !empty($request->page) ? $request->page : 1;
        $perPage = !empty($request->perPage) ? (int) $request->perPage : ApiHelper::perPageItem();
        $search = $request->search;
        $sortBY = $request->sortBy;
        $ASCTYPE = $request->orderBY;
        $language = $request->language;



        if ($userType == 'subscriber') {
            $data_query = PostCategory::where('parent_id', 0);

            if (!empty($search)) {
                $data_query = $data_query->where("category_name", "LIKE", "%{$search}%");
            }

            /* order by sorting */
            if (!empty($sortBY) && !empty($ASCTYPE)) {
                $data_query = $data_query->orderBy($sortBY, $ASCTYPE);
            } else {
                $data_query = $data_query->orderBy('sort_order', 'ASC');
            }

            $skip = ($current_page == 1) ? 0 : (int) ($current_page - 1) * $perPage;

            $user_count = $data_query->count();

            $data_list = $data_query->skip($skip)->take($perPage)->get();
            $data_list = $data_list->map(function ($data)  use ($language) {
                $data->image = ApiHelper::getFullImageUrl($data->image_id);

                $post_Cat_details = $data->descriptionDetails()->where('languages_id', 1)->first();
                $data->catName =  ($post_Cat_details == null) ? '' : $post_Cat_details->category_name;
                // getting sub cate
                $sub_cat = PostCategory::where('parent_id', $data->category_id)->get();

                if (sizeof($sub_cat) > 0) {
                    $sub_cat = $sub_cat->map(function ($sub) {
                        $sub->image = ApiHelper::getFullImageUrl($sub->image_id);
                        $post_sub_cat_details = $sub->descriptionDetails()->where('languages_id', 1)->first();
                        $sub->catName =  ($post_sub_cat_details == null) ? '' : $post_sub_cat_details->category_name;

                        return $sub;
                    });
                }

                $data->sub_cat = $sub_cat;
                return $data;
            });
        } else {

            $data_query = SuperPostCategory::where('parent_id', 0);

            if (!empty($search)) {
                $data_query = $data_query->where("category_name", "LIKE", "%{$search}%");
            }

            /* order by sorting */
            if (!empty($sortBY) && !empty($ASCTYPE)) {
                $data_query = $data_query->orderBy($sortBY, $ASCTYPE);
            } else {
                $data_query = $data_query->orderBy('sort_order', 'ASC');
            }

            $skip = ($current_page == 1) ? 0 : (int) ($current_page - 1) * $perPage;

            $user_count = $data_query->count();

            $data_list = $data_query->skip($skip)->take($perPage)->get();
            $data_list = $data_list->map(function ($data)  use ($language) {
                $data->image = ApiHelper::getFullImageUrl($data->image_id);

                // getting sub cate
                $sub_cat = SuperPostCategory::where('parent_id', $data->category_id)->get();

                if (sizeof($sub_cat) > 0) {
                    $sub_cat = $sub_cat->map(function ($sub) {
                        $sub->image = ApiHelper::getFullImageUrl($sub->image_id);
                        return $sub;
                    });
                }
                $data->sub_cat = $sub_cat;
                return $data;
            });
        }


        $res = [
            'data' => $data_list,
            'current_page' => $current_page,
            'total_records' => $user_count,
            'total_page' => ceil((int) $user_count / (int) $perPage),
            'per_page' => $perPage,
        ];
        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }


    public function create(Request $request)
    {
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);

        if ($userType == 'subscriber') {
            $parent_type = PostCategory::all();
            $language = ApiHelper::allSupportLang();
        } else {
            $parent_type = SuperPostCategory::all();
            $language = ApiHelper::allSuperSupportLang();
        }
        $data = [

            'parent_type' => $parent_type,
            'language' => $language,

        ];

        if ($data)
            return ApiHelper::JSON_RESPONSE(true, $data, '');
        else
            return ApiHelper::JSON_RESPONSE(false, [], '');
    }

    public function store(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        $page_access = ($userType == 'subscriber' ? $this->page : $this->landingpage);
        if (!ApiHelper::is_page_access($api_token, $page_access, $this->pageadd))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');


        if ($userType == 'subscriber') {
            //validation
            foreach (ApiHelper::allSupportLang() as $key => $value) {

                //validation check 
                $validator = Validator::make(
                    $request->all(),
                    [
                        'category_name_' . $value->languages_id => 'required',

                    ],
                    [

                        'category_name_' . $value->languages_id . '.required' => $value->languages_name . '_' . 'CATEGORY_NAME_REQUIRED',

                    ]



                );
                if ($validator->fails())
                    return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());
            }



            foreach (ApiHelper::allSupportLang() as $key => $value) {

                $cat_name = "category_name_" . $value->languages_id;
                $desc = "category_description_" . $value->languages_id;
                $title = "seometa_title_" . $value->languages_id;
                $categories_meta_desc = "seometa_desc_" . $value->languages_id;

                // store form 
                $saveData =  $request->only(['category_name', 'parent_id', 'image_id']);
                if (empty($request->category_slug)) {
                    $saveData['category_slug']  =  ApiHelper::getUniqueValue('PostCategory',  'category_slug', [2, 2], $request->$cat_name, false);
                } else {
                    $saveData['category_slug']
                        = ApiHelper::getUniqueValue('PostCategory',  'category_slug', [2, 2], $request->category_slug, false);
                }

                $catSlug = PostCategory::where('category_slug',  $request->category_slug)->first();
                if (empty($catSlug)) {
                    if ($saveData['image_id'] != '') {
                        ApiHelper::image_upload_with_crop($api_token, $saveData['image_id'], 1, 'postCategory', '', false);
                    }


                    $postCategory = PostCategory::create($saveData);
                } else {
                    return ApiHelper::JSON_RESPONSE(false, [], 'POSTS_CAT_SLUG_ALREADY_EXISTS');
                }

                $catDesc = PostCategoryDescription::create([
                    'category_id' => $postCategory->category_id,
                    'category_name' => $request->$cat_name,
                    'category_description' => $request->$desc,
                    'languages_id' => 1,

                ]);



                if (
                    !empty($request->$title) || !empty($request->$categories_meta_desc)
                ) {

                    $seo = SeoMeta::create([
                        'page_type' => 7,
                        'reference_id' => $catDesc->category_descriptions_id,
                        'language_id' => 1,
                        'seometa_title' => $request->$title,
                        'seometa_desc' => $request->$categories_meta_desc,
                    ]);
                }
            }
        } else {

            // store form 
            $saveData =  $request->only(['category_name', 'parent_id', 'image_id']);
            $saveData['category_slug'] = Str::slug($request->category_name);

            if ($saveData['image_id'] != '') {
                ApiHelper::image_upload_with_crop($api_token, $saveData['image_id'], 1, 'postCategory', '', false);
            }


            $postCategory = SuperPostCategory::create($saveData);
        }





        return ApiHelper::JSON_RESPONSE(true, $postCategory, 'SUCCESS_POST_CATEGORY_ADD');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    public function edit(Request $request)
    {
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);



        if ($userType == 'subscriber') {
            $data_list = PostCategory::with('descriptionDetails', 'descriptionDetails.seo')->find($request->category_id);
            if (!empty($data_list))
                $data_list->banner_cat_image = ApiHelper::getFullImageUrl($data_list->image_id, 'index-list');
            $parent_type = PostCategory::all();
        } else {

            $data_list = SuperPostCategory::find($request->category_id);
            if (!empty($data_list))
                $data_list->banner_cat_image = ApiHelper::getFullImageUrl($data_list->image_id, 'index-list');
            $parent_type = SuperPostCategory::all();
        }



        $data = [
            'data_list' => $data_list,
            'parent_type' => $parent_type,

        ];


        return ApiHelper::JSON_RESPONSE(true, $data, '');
    }

    //This Function is used to update the particular plan data
    public function update(Request $request)
    {

        // Validate user page access
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        $page_access = ($userType == 'subscriber' ? $this->page : $this->landingpage);
        if (!ApiHelper::is_page_access($api_token, $page_access, $this->pageupdate))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

        $category_id = $request->category_id;


        if ($userType == 'subscriber') {
            $saveData =  $request->only(['category_name', 'parent_id', 'image_id', 'status']);
            $saveData['category_slug'] = Str::slug($request->category_name);

            if ($saveData['image_id'] != '') {
                ApiHelper::image_upload_with_crop($api_token, $saveData['image_id'], 1, 'postCategory', '', false);
            }

            PostCategory::where('category_id', $category_id)->update($saveData);

            foreach (ApiHelper::allSupportLang() as $key => $value) {

                //validation check 
                $validator = Validator::make(
                    $request->all(),
                    [
                        'category_name_' . $value->languages_id => 'required',

                    ],
                    [

                        'category_name_' . $value->languages_id . '.required' => $value->languages_name . '_' . 'CATEGORY_NAME_REQUIRED',

                    ]



                );
                if ($validator->fails())
                    return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());
            }


            foreach (ApiHelper::allSupportLang() as $key => $value) {
                $cat_name = "category_name_" . $value->languages_id;
                $desc = "category_description_" . $value->languages_id;
                $seometa_title = "seometa_title_" . $value->languages_id;
                $seometa_desc = "seometa_desc_" . $value->languages_id;

                if ($value->languages_code == 'en') {
                    $post_cat_data = PostCategory::find($category_id);

                    if (empty($request->category_slug)) {
                        $post_cat_data->category_slug = Str::slug($request->$cat_name);
                    } else {

                        $post_cat_data->category_slug = $request->category_slug;
                    }

                    $post_cat_data->save();
                }

                $Postdes = PostCategoryDescription::updateOrCreate([
                    'category_id' => $category_id,
                    'languages_id' => 1,
                ], [
                    'category_name' => $request->$cat_name,
                    'category_description' => $request->$desc,
                    'languages_id' => 1,
                ]);

                if (!empty($request->$seometa_title) || !empty($request->$seometa_desc)) {
                    // update or create  seo meta details
                    SeoMeta::updateOrCreate([
                        'page_type' => 7,
                        'reference_id' => $Postdes->category_descriptions_id,
                        'language_id' => 1,
                    ], [
                        'seometa_title' => $request->$seometa_title, 'seometa_desc' => $request->$seometa_desc,
                    ]);
                }
            } //end foreach




        } else {

            $saveData =  $request->only(['category_name', 'parent_id', 'image_id', 'status']);
            $saveData['category_slug'] = Str::slug($request->category_name);

            if ($saveData['image_id'] != '') {
                ApiHelper::image_upload_with_crop($api_token, $saveData['image_id'], 1, 'postCategory', '', false);
            }


            SuperPostCategory::where('category_id', $category_id)->update($saveData);
        }



        return ApiHelper::JSON_RESPONSE(true, $saveData, 'SUCCESS_POST_CATEGORY_UPDATE');
    }



    //This Function is used to get the change the form status
    public function changeStatus(Request $request)
    {
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        if ($userType == 'subscriber') {
            $infoData = PostCategory::find($request->category_id);
            $infoData->status = ($infoData->status == 0) ? 1 : 0;
            $infoData->save();
        } else {

            $infoData = SuperPostCategory::find($request->category_id);
            $infoData->status = ($infoData->status == 0) ? 1 : 0;
            $infoData->save();
        }


        return ApiHelper::JSON_RESPONSE(true, $infoData, 'SUCCESS_STATUS_UPDATE');
    }

    public function sortOrder(Request $request)
    {
        $api_token = $request->api_token;
        $category_id = $request->category_id;
        $sort_order = $request->sort_order;


        $userType = ApiHelper::userType($api_token);
        if ($userType == 'subscriber') {
            $infoData =  PostCategory::find($category_id);
            if (empty($infoData)) {
                $infoData = new PostCategory();
                $infoData->category_id = $category_id;
                $infoData->sort_order = $sort_order;


                $infoData->save();
            } else {
                $infoData->sort_order = $sort_order;
                $infoData->save();
            }
        } else {
            $infoData =  SuperPostCategory::find($category_id);
            if (empty($infoData)) {
                $infoData = new SuperPostCategory();
                $infoData->category_id = $category_id;
                $infoData->sort_order = $sort_order;


                $infoData->save();
            } else {
                $infoData->sort_order = $sort_order;
                $infoData->save();
            }
        }




        return ApiHelper::JSON_RESPONSE(true, $infoData, 'SUCCESS_SORT_ORDER_UPDATE');
    }
}
