<?php

namespace Modules\WebsiteSetting\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use Modules\WebsiteSetting\Models\PostCategory;
use Modules\WebsiteSetting\Models\PostToCategory;
use Modules\WebsiteSetting\Models\PostTag;
use Modules\WebsiteSetting\Models\Super\SuperPostTag;
use Illuminate\Support\Str;
use Modules\WebsiteSetting\Models\PostTagDescription;
use Modules\Ecommerce\Models\SeoMeta;


use ApiHelper;


class PostTagController extends Controller
{
    public $page = 'blog_setting';
    public $landingpage = 'super_blog_setting';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';


    public function index(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        $page_access = ($userType == 'subscriber' ? $this->page : $this->landingpage);
        if (!ApiHelper::is_page_access($api_token, $page_access, $this->pageview))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');


        $current_page = !empty($request->page) ? $request->page : 1;
        $perPage = !empty($request->perPage) ? (int) $request->perPage : ApiHelper::perPageItem();
        $search = $request->search;
        $sortBY = $request->sortBy;
        $ASCTYPE = $request->orderBY;
        $language = $request->language;


        if ($userType == 'subscriber') {
            $data_query = PostTag::query();
        } else {

            $data_query = SuperPostTag::query();
        }

        if (!empty($search)) {
            $data_query = $data_query->where("tags_name", "LIKE", "%{$search}%");
        }


        /* order by sorting */
        if (!empty($sortBY) && !empty($ASCTYPE)) {
            $data_query = $data_query->orderBy($sortBY, $ASCTYPE);
        } else {
            $data_query = $data_query->orderBy('tags_id', 'ASC');
        }

        $skip = ($current_page == 1) ? 0 : (int) ($current_page - 1) * $perPage;

        $user_count = $data_query->count();

        $data_list = $data_query->skip($skip)->take($perPage)->get();

        $data_list = $data_list->map(function ($data) use ($language) {
            $post_Cat_details = $data->descriptionDetails()->where('languages_id', 1)->first();
            $data->TagName =  ($post_Cat_details == null) ? '' : $post_Cat_details->tags_name;

            return $data;
        });


        $res = [
            'data' => $data_list,
            'current_page' => $current_page,
            'total_records' => $user_count,
            'total_page' => ceil((int) $user_count / (int) $perPage),
            'per_page' => $perPage,
        ];
        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }


    public function language_list($api_token)
    {
        $api_token = $api_token;

        $userType = ApiHelper::userType($api_token);
        if ($userType == 'subscriber') {

            $language = ApiHelper::allSupportLang();
        } else {

            $language = ApiHelper::allSuperSupportLang();
        }

        return $language;
    }



    public function create(Request $request)
    {

        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        if ($userType == 'subscriber') {

            $language = ApiHelper::allSupportLang();
        } else {

            $language = ApiHelper::allSuperSupportLang();
        }


        $res = [
            'language' => $language,

        ];


        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }


    public function store(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        $page_access = ($userType == 'subscriber' ? $this->page : $this->landingpage);
        if (!ApiHelper::is_page_access($api_token, $page_access, $this->pageadd))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

        if ($userType == 'subscriber') {

            foreach (ApiHelper::allSupportLang() as $key => $value) {

                //validation check 
                $validator = Validator::make(
                    $request->all(),
                    [
                        'tags_name_' . $value->languages_id => 'required',

                    ],
                    [

                        'tags_name_' . $value->languages_id . '.required' => $value->languages_name . '_' . 'TAG_NAME_REQUIRED',

                    ]



                );
                if ($validator->fails())
                    return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());
            }

            foreach (ApiHelper::allSupportLang() as $key => $value) {

                $tags_name = "tags_name_" . $value->languages_id;
                $desc = "tags_description_" . $value->languages_id;
                $title = "seometa_title_" . $value->languages_id;
                $seometa_desc = "seometa_desc_" . $value->languages_id;

                // store form 
                $saveData =  $request->only(['tags_slug']);

                if (empty($request->tags_slug)) {
                    $saveData['tags_slug']  =  ApiHelper::getUniqueValue('PostTag',  'tags_slug', [2, 2], $request->$tags_name, false);
                } else {
                    $saveData['tags_slug']
                        = ApiHelper::getUniqueValue('PostTag',  'tags_slug', [2, 2], $request->tags_slug, false);
                }

                $tagSlug = PostTag::where('tags_slug',  $request->tags_slug)->first();
                if (empty($tagSlug)) {
                    $postTag = PostTag::create($saveData);
                } else {
                    return ApiHelper::JSON_RESPONSE(false, [], 'POSTS_TAG_SLUG_ALREADY_EXISTS');
                }

                $tagDesc = PostTagDescription::create([
                    'tags_id' => $postTag->tags_id,
                    'tags_name' => $request->$tags_name,
                    'tags_description' => $request->$desc,
                    'languages_id' => 1,

                ]);



                if (
                    !empty($request->$title) || !empty($request->$seometa_desc)
                ) {

                    $seo = SeoMeta::create([
                        'page_type' => 6,
                        'reference_id' => $tagDesc->tags_descriptions_id,
                        'language_id' => 1,
                        'seometa_title' => $request->$title,
                        'seometa_desc' => $request->$seometa_desc,
                    ]);
                }
            }
        } else {
            // store form 
            $saveData =  $request->only(['tags_name']);

            $tags = SuperPostTag::where('tags_name', $request->tags_name)->first();

            if (empty($tags)) {
                $postTag = SuperPostTag::create($saveData);
            } else {
                return ApiHelper::JSON_RESPONSE(false, [], 'TAGS_NAME_ALREADY_EXIST');
            }
        }

        return ApiHelper::JSON_RESPONSE(true, $postTag, 'SUCCESS_POST_TAG_ADD');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    public function edit(Request $request)
    {
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);

        if ($userType == 'subscriber') {
            $data_list = PostTag::with('descriptionDetails', 'descriptionDetails.seo')->find($request->tags_id);
        } else {
            $data_list = SuperPostTag::find($request->tags_id);
        }


        $data = [
            'data_list' => $data_list,

        ];


        return ApiHelper::JSON_RESPONSE(true, $data, '');
    }

    //This Function is used to update the particular plan data
    public function update(Request $request)
    {

        // Validate user page access
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        $page_access = ($userType == 'subscriber' ? $this->page : $this->landingpage);
        if (!ApiHelper::is_page_access($api_token, $page_access, $this->pageupdate))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

        $tags_id = $request->tags_id;


        if ($userType == 'subscriber') {
            // store form 
            foreach (ApiHelper::allSupportLang() as $key => $value) {

                //validation check 
                $validator = Validator::make(
                    $request->all(),
                    [
                        'tags_name_' . $value->languages_id => 'required',

                    ],
                    [

                        'tags_name_' . $value->languages_id . '.required' => $value->languages_name . '_' . 'TAG_NAME_REQUIRED',

                    ]



                );
                if ($validator->fails())
                    return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());
            }


            foreach (ApiHelper::allSupportLang() as $key => $value) {
                $tags_name = "tags_name_" . $value->languages_id;
                $desc = "tags_description_" . $value->languages_id;
                $seometa_title = "seometa_title_" . $value->languages_id;
                $seometa_desc = "seometa_desc_" . $value->languages_id;

                if ($value->languages_code == 'en') {
                    $post_cat_data = PostTag::find($tags_id);

                    if (empty($request->tags_slug)) {
                        $post_cat_data->tags_slug = Str::slug($request->$tags_name);
                    } else {

                        $post_cat_data->tags_slug = $request->tags_slug;
                    }

                    $post_cat_data->save();
                }

                $postCategory = PostTagDescription::updateOrCreate([
                    'tags_id' => $tags_id,
                    'languages_id' => 1,
                ], [
                    'tags_name' => $request->$tags_name,
                    'tags_description' => $request->$desc,
                    'languages_id' => 1,
                ]);

                if (!empty($request->$seometa_title) || !empty($request->$seometa_desc)) {
                    // update or create  seo meta details
                    SeoMeta::updateOrCreate([
                        'page_type' => 6,
                        'reference_id' => $postCategory->tags_descriptions_id,
                        'language_id' => 1,
                    ], [
                        'seometa_title' => $request->$seometa_title, 'seometa_desc' => $request->$seometa_desc,
                    ]);
                }
            } //end foreach



        } else {

            // store form 
            $saveData =  $request->only(['tags_name', 'status']);

            $postCategory = SuperPostTag::where('tags_id', $tags_id)->update($saveData);
        }





        return ApiHelper::JSON_RESPONSE(true, $postCategory, 'SUCCESS_POST_TAG_UPDATE');
    }



    //This Function is used to get the change the form status
    public function changeStatus(Request $request)
    {
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        if ($userType == 'subscriber') {
            $infoData = PostTag::find($request->tags_id);
            $infoData->status = ($infoData->status == 0) ? 1 : 0;
            $infoData->save();
        } else {
            $infoData = SuperPostTag::find($request->tags_id);
            $infoData->status = ($infoData->status == 0) ? 1 : 0;
            $infoData->save();
        }


        return ApiHelper::JSON_RESPONSE(true, $infoData, 'SUCCESS_STATUS_UPDATE');
    }
}
