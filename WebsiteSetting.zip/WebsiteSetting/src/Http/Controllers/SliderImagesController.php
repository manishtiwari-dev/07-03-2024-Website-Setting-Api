<?php

namespace Modules\WebsiteSetting\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;

use Modules\WebsiteSetting\Models\Slider;
use Modules\WebsiteSetting\Models\SliderImages;


use Illuminate\Http\Request;
use ApiHelper;


class SliderImagesController extends Controller
{


    public $page = 'web_slider';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';


    public function index(Request $request)
    {

        // Validate user page access
        $api_token = $request->api_token;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageview)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        $data_list = Slider::all();


        $res = [
            'data_list' => $data_list
        ];
        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function list(Request $request)
    {

        // Validate user page access
        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageview)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        $info = Slider::find($request->sliders_id);
        $data_list = SliderImages::where('sliders_id', $request->sliders_id)->orderBy('sort_order', 'ASC')->get();

        // display each image 
        if (!empty($data_list)) {
            $data_list = $data_list->map(function ($data) {
                $data->image = ApiHelper::getFullImageUrl($data->sliders_image, 'index-list');
                return $data;
            });
        }



        $res = [
            'data_list' => $data_list,
            'info' => $info,
        ];
        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }


    public function store(Request $request)
    {
        $api_token = $request->api_token;

        // Validate user page access
        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        $slider_images_data = $request->except(['api_token']);
        if ($slider_images_data['sliders_image'] != '')
            ApiHelper::image_upload_with_crop($api_token, $slider_images_data['sliders_image'], 1, 'slider', '', false);
        $data = SliderImages::create($slider_images_data);
        if ($data)
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_SLIDER_IMAGES_ADD');
        else
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_SLIDER_IMAGES_ADD');
    }

    public function edit(Request $request)
    {
        $api_token = $request->api_token;
        $data_list = SliderImages::with('slider_images')->where('id', $request->id)->first();

        $data_list->image = ApiHelper::getFullImageUrl($data_list->sliders_image, 'index-list');


        return ApiHelper::JSON_RESPONSE(true, $data_list, '');
    }

    public function update(Request $request)
    {
        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        $slider_images_data = $request->only(['sliders_id', 'sliders_url', 'sliders_image', 'sliders_html_text', 'sliders_name', 'sort_order', 'status']);

        if ($slider_images_data['sliders_image'] != '')
            ApiHelper::image_upload_with_crop($api_token, $slider_images_data['sliders_image'], 1, 'slider', '', false);
        $data = SliderImages::where('id', $request->id)->update($slider_images_data);
        if ($slider_images_data)
            return ApiHelper::JSON_RESPONSE(true, $slider_images_data, 'SUCCESS_SLIDER_IMAGES_UPDATE');
        else
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_SLIDER_IMAGES_UPDATE');
    }


    public function destroy(Request $request)
    {
        $api_token = $request->api_token;

        $status = SliderImages::where('id', $request->id)->delete();
        if ($status) {
            return ApiHelper::JSON_RESPONSE(true, [], 'SUCCESS_SLIDER_IMAGES_DELETE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_SLIDER_IMAGES_DELETE');
        }
    }

    public function changeStatus(Request $request)
    {

        $api_token = $request->api_token;
        $id = $request->id;
        $sub_data = SliderImages::find($id);
        $sub_data->status = ($sub_data->status == 0) ? 1 : 0;
        $sub_data->save();

        return ApiHelper::JSON_RESPONSE(true, $sub_data, 'SUCCESS_STATUS_UPDATE');
    }

    public function sortOrder(Request $request)
    {
        $api_token = $request->api_token;
        $id = $request->id;
        $sort_order = $request->sort_order;
        $infoData =  SliderImages::find($id);
        if (empty($infoData)) {
            $infoData = new SliderImages();
            $infoData->id = $id;
            $infoData->sort_order = $sort_order;
            $infoData->status = 1;

            $infoData->save();
        } else {
            $infoData->sort_order = $sort_order;
            $infoData->save();
        }

        return ApiHelper::JSON_RESPONSE(true, $infoData, 'SUCCESS_SORT_ORDER_UPDATE');
    }
}
