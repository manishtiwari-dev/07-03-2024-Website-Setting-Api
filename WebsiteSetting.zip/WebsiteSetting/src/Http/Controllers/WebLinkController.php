<?php

namespace Modules\WebsiteSetting\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use ApiHelper;
use App\Models\User;
use Exception;
use Illuminate\Support\Facades\Validator;
use DateTime;
use Modules\Ecommerce\Models\SeoMeta;
use Modules\WebsiteSetting\Models\WebLink;
use Modules\WebsiteSetting\Models\Super\LandingWebLinks;
use Modules\WebsiteSetting\Models\Super\LandingSeoMeta;



class WebLinkController extends Controller
{

    public $page = 'custom_link';
    public $landingpage = 'custom_link';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';


    public function index(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        $page_access = ($userType == 'subscriber' ? $this->page : $this->landingpage);
        if (!ApiHelper::is_page_access($api_token, $page_access, $this->pageview))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');


        $dbPerpage = ApiHelper::perPageItem();
        $current_page = !empty($request->page) ? $request->page : 1;
        $perPage = !empty($dbPerpage) ? $dbPerpage : $request->perPage;
        $search = $request->search;

        if ($userType == 'subscriber') {
            $data_query = WebLink::query();
        } else {
            $data_query = LandingWebLinks::query();
        }


        // // attaching query filter by permission(all, added,owned,both)
        // $data_query = ApiHelper::attach_query_permission_filter($data_query, $api_token, $this->page, $this->pageview);

        // search
        if (!empty($search))
            $data_query = $data_query->where("link_name", "LIKE", "%{$search}%")->OrWhere("link_url", "LIKE", "%{$search}%");



        $skip = ($current_page == 1) ? 0 : (int)($current_page - 1) * $perPage;     // apply page logic
        $data_count = $data_query->count(); // get total count
        $data_list = $data_query->skip($skip)->take($perPage)->orderBy('link_id', 'DESC')->get();

        $data_list = $data_list->map(function ($data) {
            $data->status = ($data->status == 1) ? "1" : "0";
            return $data;
        });


        $res = [
            'data' => $data_list,
            'current_page' => $current_page,
            'total_records' => $data_count,
            'total_page' => ceil((int)$data_count / (int)$perPage),
            'per_page' => $perPage,
            'start_date' => $request->start_date ?? '',
            'end_date' => $request->end_date ?? '',
            'website_url' => ApiHelper::getKeySetVal('website_url'),
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function store(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        $page_access = ($userType == 'subscriber' ? $this->page : $this->landingpage);
        if (!ApiHelper::is_page_access($api_token, $page_access, $this->pageadd))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');


        // //validation check 
        // $validator = Validator::make(
        //     $request->all(),
        //     [
        //         'redirect_from' => 'required',
        //         'redirect_to' => 'required',
        //     ],
        //     [
        //         'redirect_from.required' => 'REDIRECT_FROM_REQUIRED',
        //         'redirect_to.required' => 'REDIRECT_TO_REQUIRED',
        //     ]
        // );
        // if ($validator->fails())
        //     return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());


        $insert = $request->only(['link_name', 'link_url', 'status', 'noindex']);
        $insert['created_by'] = ApiHelper::get_adminid_from_token($api_token);

        if ($userType == 'subscriber') {
            $res = WebLink::create($insert);
            if (!empty($request->seometa_title) || !empty($request->seometa_desc)) {
                SeoMeta::create([
                    'page_type' => 5,
                    'reference_id' => $res->link_id,
                    'language_id' => 1,
                    'seometa_title' => $request->seometa_title,
                    'seometa_desc' => $request->seometa_desc,

                ]);
            }
        } else {
            $res = LandingWebLinks::create($insert);
            if (!empty($request->seometa_title) || !empty($request->seometa_desc)) {
                LandingSeoMeta::create([
                    'page_type' => 5,
                    'reference_id' => $res->link_id,
                    'language_id' => 1,
                    'seometa_title' => $request->seometa_title,
                    'seometa_desc' => $request->seometa_desc,

                ]);
            }
        }


        if ($res)
            return ApiHelper::JSON_RESPONSE(true, $res->id, 'SUCCESS_WEB_LINK_ADD');
        else
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_WEB_LINK_ADD');
    }

    public function edit(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        $page_access = ($userType == 'subscriber' ? $this->page : $this->landingpage);
        if (!ApiHelper::is_page_access($api_token, $page_access, $this->pageview))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

        if ($userType == 'subscriber') {
            $web_links = WebLink::where('link_id', $request->link_id)->first();
            $seo_meta = SeoMeta::where(['page_type' => 5, 'reference_id' => $web_links->link_id])->first();
        } else {
            $web_links = LandingWebLinks::where('link_id', $request->link_id)->first();
            $seo_meta = LandingSeoMeta::where(['page_type' => 5, 'reference_id' => $web_links->link_id])->first();
        }


        $res = [
            'web_link' => $web_links,
            'seo_meta' => $seo_meta,
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function update(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        $page_access = ($userType == 'subscriber' ? $this->page : $this->landingpage);
        if (!ApiHelper::is_page_access($api_token, $page_access, $this->pageupdate))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');


        // //validation check 
        // $validator = Validator::make(
        //     $request->all(),
        //     [
        //         'redirect_from' => 'required',
        //         'redirect_to' => 'required',
        //     ],
        //     [
        //         'redirect_from.required' => 'REDIRECT_FROM_REQUIRED',
        //         'redirect_to.required' => 'REDIRECT_TO_REQUIRED',
        //     ]
        // );
        // if ($validator->fails())
        //     return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());

        $insert = $request->only(['link_name', 'link_url', 'status', 'noindex']);

        try {

            if ($userType == 'subscriber') {
                $res = WebLink::where('link_id', $request->link_id)->update($insert);
                //  $seometa = SeoMeta::where(['page_type' => 5, 'reference_id' => $request->link_id]);
                if (!empty($request->seometa_title) || !empty($request->seometa_desc)) {
                    $seoMeta = SeoMeta::where(['page_type' => 5, 'reference_id' => $request->link_id])->update([
                        'language_id' => 1,
                        'seometa_title' => $request->seometa_title,
                        'seometa_desc' => $request->seometa_desc,

                    ]);
                }
            } else {
                $res = LandingWebLinks::where('link_id', $request->link_id)->update($insert);
                //   $seometa = LandingSeoMeta::where(['page_type' => 5, 'reference_id' => $request->link_id]);
                if (!empty($request->seometa_title) || !empty($request->seometa_desc)) {
                    $seoMeta = LandingSeoMeta::where(['page_type' => 5, 'reference_id' => $request->link_id])->update([
                        'language_id' => 1,
                        'seometa_title' => $request->seometa_title,
                        'seometa_desc' => $request->seometa_desc,

                    ]);
                }
            }

            return ApiHelper::JSON_RESPONSE(true, $res, 'SUCCESS_WEB_LINK_UPDATE');
        } catch (Exception $e) {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_WEB_LINK_UPDATE');
        }
    }

    public function destroy(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        $page_access = ($userType == 'subscriber' ? $this->page : $this->landingpage);
        if (!ApiHelper::is_page_access($api_token, $page_access, $this->pagestatus))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

        $link_id = $request->link_id;

        if ($userType == 'subscriber') {
            $web_link = WebLink::where('link_id', $link_id)->delete();
            $seoMeta = SeoMeta::where(['page_type' => 5, 'reference_id' => $link_id])->delete();
        } else {
            $web_link = LandingWebLinks::where('link_id', $link_id)->delete();
            $seoMeta = LandingSeoMeta::where(['page_type' => 5, 'reference_id' => $link_id])->delete();
        }



        if ($web_link) {
            return ApiHelper::JSON_RESPONSE(true, [], 'SUCCESS_WEB_LINK_DELETE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_WEB_LINK_DELETE');
        }
    }

    public function changeStatus(Request $request)
    {
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        if ($userType == 'subscriber') {
            $infoData = WebLink::where('link_id', $request->link_id)->first();
            $infoData->status = ($infoData->status == 0) ? '1' : '0';
            $infoData->save();
        } else {
            $infoData = LandingWebLinks::where('link_id', $request->link_id)->first();
            $infoData->status = ($infoData->status == 0) ? '1' : '0';
            $infoData->save();
        }

        return ApiHelper::JSON_RESPONSE(true, $infoData, 'SUCCESS_STATUS_UPDATE');
    }
}
