<?php

namespace Modules\WebsiteSetting\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Modules\WebsiteSetting\Models\WebTestimonial;
use Modules\WebsiteSetting\Models\Super\LandingTestimonial;


use App\Models\Language;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\Models\UserBusiness;

use ApiHelper;



class WebTestimonialController extends Controller
{

    public $page = 'web_testimonial';
    public $landingpage = 'super_web_testimonial';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';

    public function index(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        $page_access = ($userType == 'subscriber' ? $this->page : $this->landingpage);
        if (!ApiHelper::is_page_access($api_token, $page_access, $this->pageview))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');


        $current_page = !empty($request->page) ? $request->page : 1;
        $perPage = !empty($request->perPage) ? (int)$request->perPage : ApiHelper::perPageItem();
        $search = $request->search;
        $sortBY = $request->sortBy;
        $ASCTYPE = $request->orderBY;
        $language = $request->language;

        if ($userType == 'subscriber') {
            $data_query = WebTestimonial::query();
        } else {
            $data_query = LandingTestimonial::query();
        }
        if (!empty($search))
            $data_query = $data_query->where("testimonial_title", "LIKE", "%{$search}%")->orWhere("customer_name", "LIKE", "%{$search}%");

        /* order by sorting */
        if (!empty($sortBY) && !empty($ASCTYPE)) {
            $data_query = $data_query->orderBy($sortBY, $ASCTYPE);
        } else {
            $data_query = $data_query->orderBy('testimonial_id', 'ASC');
        }

        $skip = ($current_page == 1) ? 0 : (int)($current_page - 1) * $perPage;

        $user_count = $data_query->count();

        $data_list = $data_query->skip($skip)->take($perPage)->get();

        $res = [
            'data' => $data_list,
            'current_page' => $current_page,
            'total_records' => $user_count,
            'total_page' => ceil((int)$user_count / (int)$perPage),
            'per_page' => $perPage
        ];
        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function store(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        $page_access = ($userType == 'subscriber' ? $this->page : $this->landingpage);
        if (!ApiHelper::is_page_access($api_token, $page_access, $this->pageadd))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

        $validator = Validator::make($request->all(), [
            'testimonial_text' => 'required',

        ], [

            'testimonial_text.required' => 'TESTIMONIAL_TEXT_REQUIRED',
        ]);
        if ($validator->fails())
            return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());

        if ($userType == 'subscriber') {
            $banner_data = $request->only('customer_name', 'company_name', 'testimonial_title', 'testimonial_text', 'status');
            $data = WebTestimonial::create($banner_data);
        } else {
            $banner_data = $request->only('customer_name', 'company_name', 'testimonial_title', 'testimonial_text', 'status');
            $data = LandingTestimonial::create($banner_data);
        }
        if ($data)
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_TESTIMONIAL_ADD');
        else
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_TESTIMONIAL_ADD');
    }

    public function edit(Request $request)
    {
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);

        if ($userType == 'subscriber') {
            $data_list = WebTestimonial::where('testimonial_id', $request->testimonial_id)->first();
        } else {
            $data_list = LandingTestimonial::where('testimonial_id', $request->testimonial_id)->first();
        }

        return ApiHelper::JSON_RESPONSE(true, $data_list, '');
    }

    public function update(Request $request)
    {

        // Validate user page access
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        $page_access = ($userType == 'subscriber' ? $this->page : $this->landingpage);
        if (!ApiHelper::is_page_access($api_token, $page_access, $this->pageupdate))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');


        $validator = Validator::make($request->all(), [

            'testimonial_text' => 'required',

        ], [

            'testimonial_text.required' => 'TESTIMONIAL_TEXT_REQUIRED',
        ]);

        if ($validator->fails())
            return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());


        if ($userType == 'subscriber') {
            $menugroup_update_data = $request->only(['customer_name', 'company_name', 'testimonial_title', 'testimonial_text', 'status']);
            WebTestimonial::where('testimonial_id', $request->testimonial_id)->update($menugroup_update_data);
        } else {
            $menugroup_update_data = $request->only(['customer_name', 'company_name', 'testimonial_title', 'testimonial_text', 'status']);
            LandingTestimonial::where('testimonial_id', $request->testimonial_id)->update($menugroup_update_data);
        }

        if ($menugroup_update_data)
            return ApiHelper::JSON_RESPONSE(true, $menugroup_update_data, 'SUCCESS_TESTIMONIAL_UPDATE');
        else
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_TESTIMONIAL_UPDATE');
    }


    public function destroy(Request $request)
    {
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        if ($userType == 'subscriber') {
            $status = WebTestimonial::where('testimonial_id', $request->testimonial_id)->delete();
        } else {
            $status = LandingTestimonial::where('testimonial_id', $request->testimonial_id)->delete();
        }

        if ($status) {
            return ApiHelper::JSON_RESPONSE(true, [], 'SUCCESS_TESTIMONIAL_DELETE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_TESTIMONIAL_DELETE');
        }
    }

    public function changeStatus(Request $request)
    {

        $api_token = $request->api_token;
        $testimonial_id = $request->testimonial_id;
        $userType = ApiHelper::userType($api_token);
        if ($userType == 'subscriber') {
            $infodata = WebTestimonial::find($testimonial_id);
            $infodata->status = ($infodata->status == 0) ? 1 : 0;
            $infodata->save();
        } else {
            $infodata = LandingTestimonial::find($testimonial_id);
            $infodata->status = ($infodata->status == 0) ? 1 : 0;
            $infodata->save();
        }
        return ApiHelper::JSON_RESPONSE(true, $infodata, 'SUCCESS_STATUS_UPDATE');
    }
}
