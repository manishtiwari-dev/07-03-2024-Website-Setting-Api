<?php

namespace Modules\WebsiteSetting\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\WebsiteSetting\Models\FormField;
use Modules\WebsiteSetting\Models\FormData;


class Form extends Model
{
    use HasFactory;
    public $timestamps = false;
    protected $primaryKey = 'form_id';
    protected $guarded = ['form_id'];

    public function getTable()
    {
        return config('dbtable.crm_form');
    }

    public function form_field(){
        return $this->hasMany(FormField::class,'form_id','form_id');
    }

    public function form_data(){
        return $this->hasMany(FormData::class,'form_id','form_id');
    }

}
