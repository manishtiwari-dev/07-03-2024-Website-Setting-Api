<?php

namespace Modules\WebsiteSetting\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FormField extends Model
{
    use HasFactory;
    public $timestamps = false;
    protected $primaryKey = 'fields_id';
    protected $guarded = ['fields_id'];

    public function getTable()
    {
        return config('dbtable.crm_form_fields');
    }

}
