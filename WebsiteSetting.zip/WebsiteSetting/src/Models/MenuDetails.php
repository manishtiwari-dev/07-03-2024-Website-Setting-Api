<?php

namespace Modules\WebsiteSetting\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\WebsiteSetting\Models\MenuGroup;

class MenuDetails extends Model
{
    use HasFactory;

    // protected $primaryKey = "menu_id";
    // protected $primaryKey = array('menu_id', 'languages_id');



    // protected $guarded = [
    //     'menu_id',
    // ];

    protected $fillable = [
        'menu_id',
        'languages_id',
        'menu_name',
        'created_at',
        'updated_at',
        'menu_label'
    ];


    public function getTable()
    {
        return config('dbtable.web_menu_details');
    }
}
