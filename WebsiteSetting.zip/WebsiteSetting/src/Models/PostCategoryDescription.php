<?php

namespace Modules\WebsiteSetting\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\Ecommerce\Models\SeoMeta;


class PostCategoryDescription extends Model
{
    use HasFactory;

    protected $primaryKey = "category_descriptions_id";

    public $timestamps = false;

    protected $guarded = [

        'category_descriptions_id',


    ];


    public function getTable()
    {
        return config('dbtable.web_post_category_descriptions');
    }


    public function seo()
    {
        return $this->hasOne(SeoMeta::class, 'reference_id', 'category_descriptions_id')->where('page_type', 7);
    }
}
