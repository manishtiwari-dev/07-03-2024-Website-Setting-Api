<?php

namespace Modules\WebsiteSetting\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\WebsiteSetting\Models\Slider;


class SliderImages extends Model
{
    use HasFactory;

    protected $primaryKey = "id";

    public $timestamps = false;

    protected $guarded=[
     
     'id',


    ];
     
    
    public function getTable()
    {
        return config('dbtable.web_sliders_images');
    }

    public function slider_images(){
        return $this->belongsTo(Slider::class, 'sliders_id','sliders_id');
    }



}
