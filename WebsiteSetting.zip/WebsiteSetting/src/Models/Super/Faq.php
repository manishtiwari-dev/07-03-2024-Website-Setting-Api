<?php

namespace Modules\WebsiteSetting\Models\Super;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\WebsiteSetting\Models\Super\FaqGroup;

class Faq extends Model
{
    use HasFactory;

    protected $primaryKey = "id";

    public $timestamps = false;

    protected $guarded=[
     
     'id',


    ];
     
    
    
    public function getTable()
    {
        return config('dbtable.landing_web_faq');
    }

    public function faqGroup(){
        return $this->belongsTo(FaqGroup::class, 'group_id','group_id');
    }



}
