<?php

namespace Modules\WebsiteSetting\Models\Super;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\WebsiteSetting\Models\Super\LandingSeoMeta;


class LandingPagesDescription extends Model
{
    use HasFactory;

   // protected $table = "website_setting";
   protected $primaryKey = 'page_description_id';
   protected $guarded = ['page_description_id'];

    public function getTable() 
    {
        return config('dbtable.landing_web_pages_description');
    }

    public function seo(){
        return $this->hasOne(LandingSeoMeta::class, 'reference_id','page_description_id')->where('page_type',2); //pagetype 2-page
    }
}
