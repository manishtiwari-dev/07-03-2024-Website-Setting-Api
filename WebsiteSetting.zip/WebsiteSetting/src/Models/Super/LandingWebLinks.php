<?php

namespace Modules\WebsiteSetting\Models\Super;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;



class LandingWebLinks extends Model
{
    use HasFactory;
    public $timestamps = false;
    protected $primaryKey = 'link_id';
    protected $guarded = ['link_id'];

    public function getTable()
    {
        return config('dbtable.landing_web_links');
    }
}
