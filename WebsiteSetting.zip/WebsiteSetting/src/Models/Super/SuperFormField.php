<?php

namespace Modules\WebsiteSetting\Models\Super;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SuperFormField extends Model
{
    use HasFactory;

    protected $primaryKey = "fields_id";

    public $timestamps = false;

    protected $guarded = [
        'fields_id',
    ];


    public function getTable()
    {
        return config('dbtable.super_crm_form_fields');
    }
}
