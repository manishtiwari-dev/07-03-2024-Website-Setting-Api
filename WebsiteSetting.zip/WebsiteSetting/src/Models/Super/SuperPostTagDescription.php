<?php

namespace Modules\WebsiteSetting\Models\Super;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\Ecommerce\Models\SeoMeta;


class SuperPostTagDescription extends Model
{
    use HasFactory;

    protected $primaryKey = "tags_descriptions_id";

    public $timestamps = false;

    protected $guarded = [

        'tags_descriptions_id',


    ];


    public function getTable()
    {
        return config('dbtable.web_post_tags_descriptions');
    }


    public function seo()
    {
        return $this->hasOne(SeoMeta::class, 'reference_id', 'tags_descriptions_id')->where('page_type', 6);
    }
}
