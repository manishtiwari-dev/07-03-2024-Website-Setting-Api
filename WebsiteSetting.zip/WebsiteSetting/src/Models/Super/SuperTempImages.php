<?php

namespace Modules\WebsiteSetting\Models\Super;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SuperTempImages extends Model
{
    use HasFactory;

    protected $connection='mysqlSuper';
    //protected $table = "lab_superadmin.app_images";
    protected $primaryKey='images_id';
    public $timestamps = false;
    protected $fillable=
    [
        'images_type',
        'images_name',
        'images_ext',
        'images_directory',
        'images_size',
        
    ];

    public function getTable()
    {
       return config('dbtable.super_app_images');
    }


    
}
