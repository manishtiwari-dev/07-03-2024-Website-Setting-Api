<?php

namespace Modules\WebsiteSetting\Models\Super;


use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\WebsiteSetting\Models\Super\WebsiteSettingGroupKey;


class WebsiteSettingsGroup extends Model
{
    use HasFactory;

    public $timestamps = false;
    
    // protected $connection='mysqlSuper';
    // protected $table = "web_settings_group";
    protected $primaryKey = 'group_id';
    protected $fillable = [
            'group_name',
            'status',
            'created_at',
            'updated_at',
    ];


    public function getTable()
    {
       return config('dbtable.web_settings_group');
    }

    public function settings(){
        return $this->hasMany(WebsiteSettingGroupKey::class, 'group_id','group_id');
    }
}
