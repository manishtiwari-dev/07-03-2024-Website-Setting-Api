<?php

namespace Modules\WebsiteSetting\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\WebsiteSetting\Models\TemplatesSectionOptions;
use Modules\WebsiteSetting\Models\TemplatesSections;
use Modules\WebsiteSetting\Models\TemplateHtml;
use Modules\WebsiteSetting\Models\TempImages;

use Modules\WebsiteSetting\Models\Super\TemplateIndustry;



class Templates extends Model
{
    use HasFactory;

    protected $primaryKey='template_id';
    
    public $timestamps = false;
    
     protected $guarded = ['template_id'];

   
   public function image_details()
   {

    return $this->belongsTo(TempImages::class,'images_id','images_id');
   }

      public function sections()
    {
        return $this->hasMany(TemplatesSectionOptions::class,'template_id','template_id');
    }

    
    public function templatesIndu()
    {
        return $this->hasMany(TemplateIndustry::class,'template_id','template_id');
    }


    public function templatesHtml()
    {
        return $this->hasOne(TemplateHtml::class,'template_id','template_id');
    }
        
        
    public function getTable()
    {
        return config('dbtable.web_templates');
    }
    
}
