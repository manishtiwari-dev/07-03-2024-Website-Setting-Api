<?php

namespace Modules\WebsiteSetting\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\WebsiteSetting\Models\WebPagesDescription;

class WebPages extends Model
{
    use HasFactory;

   // protected $table = "website_setting";
   protected $primaryKey = 'pages_id';
   protected $guarded = ['pages_id'];


    public function getTable() 
    {
        return config('dbtable.web_pages');
    }


    public function page_description(){
        return $this->hasMany(WebPagesDescription::class, 'pages_id', 'pages_id');
    }

}
